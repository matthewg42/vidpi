#include "ofApp.h"

int main() {
	ofSetupOpenGL(550, 50, OF_WINDOW);
	ofRunApp(new ofApp());
}
