pacman -Sy --needed mpg123 gst-plugins-ugly

