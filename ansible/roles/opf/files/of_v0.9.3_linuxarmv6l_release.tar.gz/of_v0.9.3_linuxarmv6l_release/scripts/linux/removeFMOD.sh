rm -r ../../libs/fmodex
rm ../../export/linux/libs/libfmodex*
rm ../../export/linux64/libs/libfmodex*
