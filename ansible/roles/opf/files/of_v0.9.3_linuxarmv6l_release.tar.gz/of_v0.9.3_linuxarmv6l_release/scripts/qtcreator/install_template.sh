mkdir -p ${HOME}/.config/QtProject/qtcreator/templates/wizards/
cp -r templates/wizards/openFrameworks ${HOME}/.config/QtProject/qtcreator/templates/wizards/
cp -r templates/wizards/openFrameworksUpdate ${HOME}/.config/QtProject/qtcreator/templates/wizards/

